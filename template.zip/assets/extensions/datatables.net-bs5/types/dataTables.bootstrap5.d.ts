
import Api from "datatables.net";

export default Api;
